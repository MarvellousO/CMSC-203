

import java.io.IOException;
import javafx.application.Application;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;


public class FXDriver extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) {
        FXMainPane root = new FXMainPane();
        Scene scene = new Scene(root, 500, 300);
        stage.setTitle("Hello World GUI");
        stage.setScene(scene);
        stage.show();
    }
}
