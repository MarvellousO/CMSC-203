

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
/**
 * This panel is the basic panel, inside which other panels are placed.  
 * Before beginning to implement, design the structure of your GUI in order to 
 * understand what panels go inside which ones, and what buttons or other components
 * go in which panels.  
 * @author ralexander
 *
 */
//make the main panel's layout be a VBox
public class FXMainPane extends VBox {

	//student Task #2:
	//  declare five buttons, a label, and a textfield
    private Button helloButton;
    private Button howdyButton;
    private Button chineseButton;
    private Button clearButton;
    private Button exitButton;
    private Button otherLanguageButton;  // New button for another language
    private Label feedbackLabel;
    private TextField textField;

    private HBox buttonBox;
    private HBox labelAndTextFieldBox;

    private DataManager dataManager;

    public FXMainPane() {
        helloButton = new Button("Hello");
        howdyButton = new Button("Howdy");
        chineseButton = new Button("Chinese");
        clearButton = new Button("Clear");
        exitButton = new Button("Exit");
        otherLanguageButton = new Button("Other Language");  // New button
        feedbackLabel = new Label("Feedback:");
        textField = new TextField();

        buttonBox = new HBox();
        labelAndTextFieldBox = new HBox();

        dataManager = new DataManager();

        // Set margins for components
        HBox.setMargin(feedbackLabel, new Insets(10, 10, 10, 10));
        HBox.setMargin(textField, new Insets(10, 10, 10, 10));
        HBox.setMargin(helloButton, new Insets(10, 10, 10, 10));
        HBox.setMargin(howdyButton, new Insets(10, 10, 10, 10));
        HBox.setMargin(chineseButton, new Insets(10, 10, 10, 10));
        HBox.setMargin(clearButton, new Insets(10, 10, 10, 10));
        HBox.setMargin(exitButton, new Insets(10, 10, 10, 10));
        HBox.setMargin(otherLanguageButton, new Insets(10, 10, 10, 10));

        // Set alignment for HBoxes
        buttonBox.setAlignment(Pos.CENTER);
        labelAndTextFieldBox.setAlignment(Pos.CENTER);

        // Set event handlers for buttons
        helloButton.setOnAction(new ButtonHandler());
        howdyButton.setOnAction(new ButtonHandler());
        chineseButton.setOnAction(new ButtonHandler());
        clearButton.setOnAction(new ButtonHandler());
        exitButton.setOnAction(new ButtonHandler());
        otherLanguageButton.setOnAction(new ButtonHandler());

        // Add components to HBoxes
        labelAndTextFieldBox.getChildren().addAll(feedbackLabel, textField);
        buttonBox.getChildren().addAll(helloButton, howdyButton, chineseButton, clearButton, exitButton, otherLanguageButton);

        // Add HBoxes to VBox (FXMainPane)
        getChildren().addAll(buttonBox, labelAndTextFieldBox);
    }

    private class ButtonHandler implements EventHandler<ActionEvent> {
        @Override
        public void handle(ActionEvent event) {
            if (event.getSource() == helloButton) {
                textField.setText(dataManager.getHello());
            } else if (event.getSource() == howdyButton) {
                textField.setText(dataManager.getHowdy());
            } else if (event.getSource() == chineseButton) {
                textField.setText(dataManager.getChinese());
            } else if (event.getSource() == clearButton) {
                textField.clear();
            } else if (event.getSource() == exitButton) {
                Platform.exit();
                System.exit(0);
            } else if (event.getSource() == otherLanguageButton) {
                textField.setText(dataManager.getOtherLanguage());
            }
        }
    }
}
